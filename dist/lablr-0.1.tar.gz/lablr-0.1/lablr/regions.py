from lablr import TextItem, Region, SingleItemRegion


class MultilineTextItem(object):
    output_path = 'multitext.png'
    text_lines = list()
    padding = 0
    font_size = 20
    font_name = 'Arial.ttf'
    align = 'center'
    font_color = (0, 0)

    def render(self):
        main_height = self.padding
        self.main = Region('main', **kwargs)

        text_regions = [
            TextItem(line, line, font_name=self.font_name, font_size=self.font_size, font_color=self.font_color, **kwargs)
            for line in self.text_lines
        ]
        main_width = max([r.size.width for r in text_regions])
        largest_height = max([r.size.height for r in text_regions])

        for text_region in text_regions:
            region = SingleItemRegion(
                'region__' + line,
                text_region,
                size=text_region.size,
                align=align,
                vertical_align='middle',
                **kwargs
            )
            region.size = (main_width, largest_height)
            region.position = (self.padding, main_height)
            main_height += region.size.height
            self.main.add_item(region)
        self.main.size = (main_width+(self.padding*2), main_height+self.padding)

    def save(self):
        self.render()
        self.main.save(self.output_path)
        self.main.image.show()